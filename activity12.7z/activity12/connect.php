<?php
$connect= mysqli_connect("localhost", "root","","activity12")
or die("Cannot connect to the database");
?>