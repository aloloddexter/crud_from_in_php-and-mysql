<?
require_once('connect.php');
$dname=$_POST['fname'];
$dname=$_POST['lname'];
$bday=$_POST['bday'];
$gender=$_POST['sex'];
$sma= implode('', $_POST['sma']);

mysqli_query($connect, "insert into signup values(NULL,'$dname','$bday','$gender','$sma', 'Active');");

echo'<meta http-equiv="refresh" content="0; main.php>';

?>