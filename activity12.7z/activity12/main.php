<!DOCTYPE html>
<html>
    <head>
        <title>Activity 12</title>
        <link rel="stylesheet" href="style4.css" />
    </head>
    <body>
    <div class="container">
        <div class="head">
            <h1>NEMSU</h1>
            <nav class="navbar">
                <ul>
                    <li><a href="">SIGN-UP</a></li>
                    <li><a href="" >ACCOUNT</a></li>
                </ul>
            </nav>
        </div>
    </div>
    <form action="account.php" method="post">
        <label>First name:</label>
        <input type="text" name="fname" placeholder="First name" /><br>
        <label>Last name:</label>
        <input type="text" name="lname" placeholder="Last name" /><br>
        <label for="bday">Birthday</label><br>
         <input type="date" name="bday"  required /><br>
         <label>Gender</label><br>
         <select name="gender">
            <option value="Male" name="gender">Male</option>
            <option value="Female" name="gender">Female</option>
            <option value="Custom">Custom</option>
        </select><br>
        <label for="sma">Programming Language Proficiency:</label>
        <input type="checkbox" id="C++" name="sma[]" value="C++" />
        <label for="C++">C++</label>
        <input type="checkbox" id="Java" name="sma[]" value="Java" />
        <label for="Java">Java</label>
        <input type="checkbox" id="HTML" name="sma[]" value="HTML" />
        <label for="HTML">HTML</label>
        <input type="checkbox" id="PHP" name="sma[]" value="PHP" />
        <label for="PHP">PHP</label><br>
        
        <input type="submit" name="submit" />
    </form><br><br>

    
</body>
</html>