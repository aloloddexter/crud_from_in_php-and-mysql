<!DOCTYPE html>
<html>
    <title>Activity 12</title>
</html>

<body>
    <form action="update.php" method="post">
    <?php
    require_once("connect.php");
    $id=$_GET['id_num'];

    $query = mysqli_query($connect,"select * from registration where id='$id';");
    $row = mysqli_fetch_array($query);
    ?>

    <label for="fname">Name:</label>
    <input type="hidden" name="id" value="<?php echo $row['id'];?>" /><br>
    <input type="text" name="fname" value="<?php echo $row['dname'];?>" /><br>
    <input type="date" name="bday" value="<?php echo $row['birthday'];?>" /><br>
    <select name="gender" value="<?php echo $row['gender'];?>">
            <option value="Male" name="gender">Male</option>
            <option value="Female" name="gender">Female</option>
            <option value="Custom">Custom</option>
        </select><br>
<label for="sma">Programming Language Proficiency:</label>
        <input type="checkbox" id="C++" name="sma[]" value="C++" />
        <label for="C++">C++</label>
        <input type="checkbox" id="Java" name="sma[]" value="Java" />
        <label for="Java">Java</label>
        <input type="checkbox" id="HTML" name="sma[]" value="HTML" />
        <label for="HTML">HTML</label>
        <input type="checkbox" id="PHP" name="sma[]" value="PHP" />
        <label for="PHP">PHP</label><br>
        
    <input type="submit" name="submit" />
    </form><br><br>

</body>