<?php
require_once('connect.php');

if (isset($_POST['id']) && isset($_POST['fname'])&& isset($_POST['lname']) && isset($_POST['bday']) && isset($_POST['gender']) && isset($_POST['sma'])) {
    $id = $_POST['id'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $bday = $_POST['bday'];
    $gender = $_POST['gender'];
    $sma = implode(' ', $_POST['sma']);

    mysqli_query($connect, "UPDATE registration SET dname='$fname', dlname='$lname', birthday='$bday',gender='$gender', proficiency='$sma' WHERE id='$id'");

    header('Location: account.php');
} else {
    echo "Form data missing";
}
?>

