<?php
require_once('connect.php');
if(isset($_GET['id_num'])){
    $id = $_GET['id_num'];
    mysqli_query($connect, "DELETE FROM registration WHERE id = '$id'");
    header("location: account.php");
}
?>
