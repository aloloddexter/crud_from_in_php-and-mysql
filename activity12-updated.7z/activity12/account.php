<?php

require_once('connect.php');

if (isset($_POST['fname']) && isset($_POST['lname']) && isset($_POST['bday']) && isset($_POST['gender']) && isset($_POST['sma'])) {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $bday = $_POST['bday'];
    $gender = $_POST['gender'];
    $sma = implode(' ', $_POST['sma']);

    mysqli_query($connect, "INSERT INTO registration (dname, dlname, birthday, gender, proficiency, status) VALUES ('$fname','$lname', '$bday', '$gender', '$sma', 'Active')");
}

?>

<table border=1 cellspacing=0>
    <tr>
        <td><b>ID Num</b></td>
        <td><b>First Name</b></td>
        <td><b>Last Name</b></td>
        <td><b>Birthday</b></td>
        <td><b>Gender</b></td>
        <td><b>PL</b></td>
        <td><b>Status</b></td>
        <td><b>Action</b></td>
    </tr>
    <?php
    require_once('connect.php');
    $query = mysqli_query($connect, "SELECT * FROM registration;");
    while ($row = mysqli_fetch_array($query)) {
    ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['dname']; ?></td>
            <td><?php echo $row['dlname']; ?></td>
            <td><?php echo $row['birthday']; ?></td>
            <td><?php echo $row['gender']; ?></td>
            <td><?php echo $row['proficiency']; ?></td>
            <td><?php echo $row['status']; ?></td>
            <td>
                <a href="update_form.php?id_num=<?php echo $row['id']; ?>">Edit</a> |
                
                <a href="delete.php?id_num=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this record?')">Delete</a>

            </td>
        </tr>
    <?php
    }
    ?>

</table>

