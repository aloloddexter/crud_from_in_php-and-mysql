<!DOCTYPE html>
<html>
    <head>
        <title>Activity 12</title>
        <link rel="stylesheet" href="style4.css" />
    </head>
    <body>
    <div class="container">
        <div class="head">
            <h1>NEMSU</h1>
            <nav class="navbar">
                <ul>
                    <li><a href="main.php">SIGN-UP</a></li>
                    <li><a href="" >ACCOUNT</a></li>
                </ul>
            </nav>
        </div>
    </div>
<body>
    <form action="update.php" method="post">
    <?php
    require_once("connect.php");
    $id=$_GET['id_num'];

    $query = mysqli_query($connect,"select * from registration where id='$id';");
    $row = mysqli_fetch_array($query);
    ?>
    <br><br><fieldset>
    
    <input type="hidden" name="id" value="<?php echo $row['id'];?>" /><br>
    <label for="fname">First Name:</label>
    <input type="text" name="fname" placeholder="Last name" value="<?php echo $row['dname'];?>" /><br>
    <label for="lname">Last Name:</label>
    <input type="text" name="lname" value="<?php echo $row['dlname'];?>" /><br>
    <label>Birthday:</label>
    <input type="date" name="bday" value="<?php echo $row['birthday'];?>" /><br>
    <label>Gender:</label>
    <select name="gender" value="<?php echo $row['gender'];?>">
            <option value="Male" name="gender">Male</option>
            <option value="Female" name="gender">Female</option>
            <option value="Custom">Custom</option>
        </select><br>
<label for="sma">Programming Language Proficiency:</label>
        <input type="checkbox" id="C++" name="sma[]" value="C++" />
        <label for="C++">C++</label>
        <input type="checkbox" id="Java" name="sma[]" value="Java" />
        <label for="Java">Java</label>
        <input type="checkbox" id="HTML" name="sma[]" value="HTML" />
        <label for="HTML">HTML</label>
        <input type="checkbox" id="PHP" name="sma[]" value="PHP" />
        <label for="PHP">PHP</label><br>
        
    <input type="submit" name="submit" />
    </fieldset>
    </form><br><br>

</body>
</html>